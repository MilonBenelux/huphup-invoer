# WhatsApp-chatexport: Hup Hup rapportages
Datum van export: 3 november 2026 om 7:36

---

## 20 oktober 2026

[8:26] **Yentl De Clippeleir:** DMD OV 🐴 19/10
L 3(15)
C 0(5)
A 0(8)
AM 3(11)
P 3(15)
I 2(11)
R 0(5)
F 0(3)

[8:52] **Wout Noppe:** Beveren 19/10
L: 1.14
C: 1.7
A: 1.5
AM: 0.7
P: 2.11
I: 1.10
R: 0.3
F: 0.1

[12:07] **Joris Verbeeck:** L 1(10)
C 2(10)
A 1(11)
AM 0(6)
P 0(3)
I 0(3)
R 1(6)
F 0(4)

20/10 Tessenderlo ochtend

[12:20] **Morena Benedetto:** L 3.19
C 1.7
A 1.20
P 1.13
I 1.21
R 0.14
F 0.14
MM 20/10

[13:37] **Natasha De Vriendt:** _Dit bericht is verwijderd_

[13:51] **Ellen Van de Voorde:** L 0.13
C 0.9
A 0.6
P 0.3
I 0.5
R 0.9
F 1.11

Hoogstraten 20/10

[13:53] **Natasha De Vriendt:** L 2.17
C 1.7
A 0.13
P 0.5 
I 0.0
R 0.3
F 1.8

Kapellen 20/10

[19:58] **Julia van de Goor:** L 2(6)
C 1(2)
A 1(6)
AM 3(6)
P 1(5)
I 1(8)
R 0(4)
F 1(9)

20/10 Tessenderlo

[20:04] **Yent'l Adams:** L 0.10
C 2.8
A 1.9
P 0.4
I 0.9
IO 0.0
B 0.0
R 0.4
F 2.7
Milo 0.5
Brasschaat 20/10

[20:21] **Rob Coppieters:** L 1.5
C 0.2
A 1.3
P 0.5
I 0.6
R 0.0
F 0.0
Stephy schoten 20/10

[20:23] **Wilma Mihaylova:** Beveren 20/10
L: 4.18
C: 1.8
A: 1.6
AM: 0.7
P: 1.12
I: 1.11
R: 0.3
F: 0.1

[20:31] **Bruno Rivas:** [Afbeelding]

[20:33] **Anousjka Christiaens:** Zandhoven 20/10
L 0.8
C 10.5
A 2.9
P 2.6
I  0.8
IO 0.3
R 0.6
B 0.0
F 0.9
Pelvi lead 0.1
Pelvi afspraak 0.0
Pelvi inschrijving 0.0
BenFit opstart 0.1

[20:44] **Isaï Melis:** L 0.4
C 0.1
A 0.5
P 0.1
I 0.1
R 0.2
F 0.3

Hoogstraten 20/10

[20:56] **Yentl De Clippeleir:** DMD OV 🐴 20/10
L 3(18)
C 4(9)
A 5(14)
AM 2(13)
P 2(17)
I 0(11)
R 1(6)
F 0(3)

[21:15] **Micky Muroni:** L 2.8
C 4.7
A 2.7
P 1.9
I 0.8
R 0.10
F 0.0
Oudsbergen 20-10

[23:55] **Pieter Vanstippelen:** L 2.10
C 1.8
A 1.9
Am 0.4
P 1.5
I 1.4
R 0.5
F 0.7
Db 20/10

---

## 21 oktober 2026

[12:47] **Ellen Van de Voorde:** L 1.14
C 2.11
A 1.7
P 1.4
I 0.5
R 2.11
F 0.11

Kapellen 21/10

[12:54] **Eva Geerts:** L 3.6
C 0.1
A 0.3
P 0.3
I 0.2
R 0.1
F 0.5

Schoten 21/10

[12:59] **+32 456 96 18 68:** L 0.1
C 0.0
A 0.0
Am 0.2
P 2.3
I 2.2
R 0.0
F 0.9
21/10 Tessenderlo ochtend

[19:49] **Gilles Lambilot:** [Afbeelding]

[19:54] **Bieke Stinkens:** L 3.22
C 0.7
A 1.21
P 2.15
I 2.23
R 0.14
F 0.14
MM 21/10

[19:55] **Wout Noppe:** Beveren 21/10
L: 5.23
C: 1.9
A: 0.6
AM: 5.12
P: 1.13
I: 1.12
R: 0.3
F: 0.1

[19:56] **Julia van de Goor:** L 1(7)
C 0(2)
A 0(6)
AM 0(6)
P 1(6)
I (8)
R 0(4)
F 1(10)

21/10 Tessenderlo

[19:58] **Yent'l Adams:** L 1.11
C 0.8
A 0.9
P 1.5 (van gisteren)
I 1.10
IO 0.0
B 0.0
R 0.4
F 0.7
Milo 0.5
Brasschaat 21/10

[20:09] **Anousjka Christiaens:** Zandhoven 21/10
L 2.8
C 3.5
A 4.9
P 2.6
I  0.8
IO 0.3
R 2.6
B 0.0
F 1.9
Pelvi lead 0.1
Pelvi afspraak 0.0
Pelvi inschrijving 0.0
BenFit opstart 0.1

[20:43] **Natasha De Vriendt:** _Dit bericht is verwijderd_

[20:49] **Ellen Van de Voorde:** L 0.14
C 0.11
A 0.7
P 0.4
I 0.5
R 0.11
F 0.11

Hoogstraten 21/10

[20:51] **Rob Coppieters:** L 1.4
C 0.3
A 1.3
P 0.1
I 0.1
R 0.2
F 1.3
Kapellen 21/10

[21:57] **Natasha De Vriendt:** L 6.23
C 3.10
A 3.16
P 0.5 
I 1.1
R 3.6
F 1.9

Schoten 21/10

---

## 22 oktober 2026

[11:21] **Rob Coppieters:** L 0.4
C 0.3
A 0.3
P 0.1
I 0.1
R 0.2
F 1.4
Hoogstraten 22/10

[11:53] **+32 456 96 18 68:** L 1.5
C 0.0
A 0.0
Am 0.2
P 0.3
I 0.2
R 0.0
F 0.0
22/10 Tessenderlo ochtend

[19:48] **Joris Verbeeck:** L 0(10)
C 0(10)
A 0(11)
AM 0(6)
P 1(4)
I 1(4)
R 0(6)
F 0(4)

22/10 Tessenderlo avond

[19:55] **Gilles Lambilot:** _Dit bericht is verwijderd_

[20:03] **+32 456 96 18 68:** L 1.7
C 0.7
A 1.3
Am 0.3
P 1.5
I 0.6
R 1.4
F 0.2
Db 22/10 avond

[20:03] **Beau Massignani:** L 2(14) (1x walk-in)
C 0(8)
A 1(7)
AM 2(6)
P 0(6)
I 0(7)
R 0(6)
F 1(10)
22/10 HH Lanaken avond

[20:07] **Morena Benedetto:** L 1.23
C 1.8
A 1.22
P 1.16
I 1.24
R 0.14
F 0.14
MM 22/10

[20:10] **Ans Van Hofstraeten:** Zandhoven 22/10
L 1.18
C 2.21
A 4.24
P 2.16
I  0.11
IO 0.3
R 0.14
B 0.0
F 1.16
Pelvi lead 0.1
Pelvi afspraak 0.0
Pelvi inschrijving 0.0
BenFit opstart 0.1

[20:16] **Eva Geerts:** L 2.8
C 2.3
A 1.4
P 0.3
I 0.2
R 0.1
F 1.6

Schoten 22/10

[20:16] **Julia van de Goor:** L 0(7)
C 0(2)
A 0(6)
AM 0(6)
P 0(6)
I 0(8)
R 0(4)
F 1(11)

22/10 Tessenderlo ochtend

[20:17] **Gilles Lambilot:** [Afbeelding]

[20:41] **Wilma Mihaylova:** Beveren 22/10
L: 2.25
C: 0.9
A: 0.6
AM: 1.13
P: 2.15 2x 2W Pas
I: 0.12
R: 0.3
F: 0.1

[20:54] **Yentl De Clippeleir:** DMD OV 🐴 22/10
L 5(21)
C 2(11)
A 1(15)
AM 0(13)
P 1(18)
I 1(12)
R 0(6)
F 0(3)

[21:52] **Isaï Melis:** L 0.4
C 0.1
A 0.5
P 0.2
I 0.1
R 1.3
F 0.3

Hoogstraten 22/10

[22:11] **Micky Muroni:** L 4.12
C 0.7
A 2.9
P 0.9
I 2.10
R 2.12
F 0.0
Oudsbergen 22-10

[22:24] **Keith D'Hooge:** L 0.0
C 0.0
A 0.0
P 1.1
I 0.0
R 0.0
F 2.3

Kapellen 22/10

---

## 23 oktober 2026

[12:55] **Bruno Rivas:** [Afbeelding]

---

## 24 oktober 2026

[11:29] **Isaï Melis:**
> _Isaï Melis: L 0.4
C 0.1
A 0.5
P 0.2
I 0.1
R 1.3
F 0.3

Hoogstraten 22/10_
L 0.4
C 0.1
A 0.5
P 0.2
I 0.1
R 0.3
F 0.3

Hoogstraten 25/10

[11:44] **Bieke Stinkens:** L 1.24
C 0.8
A 1.23
P 0.16
I 1.25
R 1.15
F 0.14
MM 24/10

[12:05] **Charlotte Elen:** L 3.14
C 1.9
A 1.10
P 2.7
I 0.10
IO 0.0
B 0.0
R 1.5
F 0.7
Milo 0.5
Brasschaat 22/10+24/10

[12:12] **Joris Verbeeck:** L 2(12)
C 0(10)
A 0(11)
AM 0(6)
P 3(7)
I 4(8)
R 0(6)
F 0(4)

24/10 Tessenderlo

[12:13] **Gilles Lambilot:** [Afbeelding]

[12:49] **Natasha De Vriendt:** L 2.25
C 2.12
A 2.18
P 1.6 
I 1.2
R 1.7
F 1.10

Kapellen 24/10

[12:56] **Wout Noppe:** Beveren 24/10
L: 5.30
C: 0.9
A: 0.6
AM: 0.13
P: 1.16
I: 1.13
R: 0.3
F: 0.1

[13:21] **Rob Coppieters:** L 0.5
C 0.2
A 0.3
P 1.6
I 0.6
R 0.0
F 0.0
Schoten 24/10

---

## 25 oktober 2026

[11:40] **Morena Benedetto:** L 2.26
C 2.10
A 2.25
P 0.16
I 0.25
R 0.15
F 0.14
MM 25/10

[12:08] **Joris Verbeeck:** L 1(13)
C 0(10)
A 0(11)
AM 1(7)
P 0(7)
I 0(8)
R 0(6)
F 0(4)

25/10 Tessenderlo

[12:09] **Beau Massignani:** L 2(23)
C 1(12)
A 0(9)
AM 0(8)
P 0(6)
I 0(7)
R 0(6)
F 0(10)
25/10 HH Lanaken ochtend

[12:37] **Natasha De Vriendt:** L 3.28
C 2.14
A 1.19
P 0.6 
I 0.2
R 0.7
F 0.10

Schoten 25/10

[12:38] **Anousjka Christiaens:** Zandhoven 25/10
L 1.19
C 2.22
A 1.24
P 1.18 
I  2.11
IO 0.3
R 0.14
B 0.0
F 0.16
Pelvi lead 0.1
Pelvi afspraak 0.0
Pelvi inschrijving 0.0
BenFit opstart 0.1

[15:39] **Keith D'Hooge:** L 0.0
C 1.1
A 1.1
P 1.2
I 0.0
R 0.0
F 1.4

Kapellen 25/10

---

## 26 oktober 2026

[11:27] **Rob Coppieters:** L 2.6
C 1.4
A 3.7
P 0.1
I 0.1
R 0.2
F 0.4
Hoogstraten 26/10

[12:27] **Joris Verbeeck:** L 2(15)
C 1(11)
A 0(11)
AM 0(7)
P 1(8)
I 1(9)
R 0(6)
F 0(4)

26/10 Tessenderlo ochtend

[12:44] **Eva Geerts:** L 2.10
C 1.4
A 2.6
P 0.3
I 0.2
R 0.1
F 0.6

Kapellen 26/10

[19:50] **Charlotte Elen:** L 7.14
C 3.12
A 3.13
P 1.8
I 0.10
R 0.5
F 1.8
Milo 1.6

Brasschaat 26/10

[19:51] **Beau Massignani:** L 6.32
C 3.13
A 4.29
P 4.20
I 3.28
R 1.16
F 0.14
MM 26/10

[20:00] **Gilles Lambilot:** [Afbeelding]

[20:36] **Julia van de Goor:** L 0(7)
C 0(2)
A 0(6)
AM 0(6)
P 1(7)
I 1(9)
R 0(4)
F 1(12)

26/10 Tessenderlo

[20:39] **Natasha De Vriendt:** _Dit bericht is verwijderd_

[20:45] **Rob Coppieters:** L 0.6
C 0.4
A 0.7
P 0.1
I 0.1
R 0.2
F 1.5
Kapellen 26/10

[20:59] **Isaï Melis:** L 0.4
C 0.1
A 0.5
P 0.2
I 0.1
R 1.4
F 0.3

Hoogstraten 26/10

[21:02] **Yentl De Clippeleir:** DMD MST🐴 22-26/10
L 7(15)
C 1(4)
A 0(5)
AM 6(12)
P 0(12)
I 1(13)
IO 0(0)
R 0(2)
F zie OV

[21:34] **Natasha De Vriendt:** L 2.30
C 1.15
A 3.22
P 2.8 
I 2.4
R 1.8
F 0.10

Schoten 26/10

[22:03] **Micky Muroni:** L 6.18
C 6.13
A 4.13
P 0.9
I 0.10
R 3.15
F 0.0
Oudsbergen 26-10

---

## 27 oktober 2026

[8:22] **Wout Noppe:** _Dit bericht is verwijderd_

[8:48] **Wout Noppe:** Beveren 26/10
L: 15.45
C: 5.14
A: 2.8
AM: 1.14
P: 1.17
I: 0.13
R: 0.3
F: 0.1

[11:07] **Yentl De Clippeleir:** DMD OV 🐴 23-25/10
L 13(34)
C 0(11)
A 0(15)
AM 5(18)
P 0(18)
I 0(12)
R 0(6)
F 0(3)

[11:08] **Yentl De Clippeleir:** DMD OV 🐴 26/10
L 5(39)
C 2(11)
A 0(15)
AM 3(21)
P 3(21)
I 5(18)
R 0(6)
F 0(3)

[11:21] **Rob Coppieters:** L 0.6
C 0.4
A 0.7
P 1.2
I 2.3
R 0.2
F 0.4
27/10 hoogstraten

[12:01] **Joris Verbeeck:** L 2(17)
C 0(11)
A 2(13)
AM 0(7)
P 0(8)
I 1(10)
R 2(8)
F 0(4)

27/10 Tessenderlo ochtend

[12:19] **+32 456 96 18 68:** L 0.11
C 2.12
A 0.3
Am 0.3
P 2.7
I 0.6
R 0.4
F 0.2
Db 27/10 ochtend

[12:47] **Morena Benedetto:** L 2.24
C 1.14
A 2.31
P 2.22
I 0.28
R 2.18
F 0.14
MM 27/10

[12:56] **Natasha De Vriendt:** L 0.30
C 1.16
A 0.22
P 1.9 
I 1.5
R 0.8
F 0.10

Kapellen 27/10 VM

[13:25] __Annick Antheunis heeft +32 468 27 83 44 toegevoegd__

[18:34] **Micky Muroni:** L 4.22
C 5.18
A 5.18
P 1.10
I 0.10
R 0.15
F 0.0
Oudsbergen 27-10

[20:11] **Julia van de Goor:** L 2(9)
C 1(3)
A 1(7)
AM 1(7)
P 0(7)
I 0(9)
R 0(4)
F 1(14)

27/10 Tessenderlo

[20:48] **Wilma Mihaylova:** Beveren 27/10
L: 1.46
C: 4.18
A: 4.12
AM: 2.16
P: 0.17
I: 0.13
R: 0.3
F: 0.1

[20:50] **Isaï Melis:** L 0.4
C 0.1
A 0.5
P 0.2
I 0.1
R 0.4
F 0.3

Hoogstraten 27/10

[20:57] **Anousjka Christiaens:** Zandhoven 27/10
L 1.24
C 1.23
A 1.31
P 2.19 
I  2.13
IO 0.3
R 0.16
B 0.0
F 0.18
Pelvi lead 0.1
Pelvi afspraak 0.0
Pelvi inschrijving 0.0
BenFit opstart 0.1

[20:59] **Yentl De Clippeleir:** DMD OV 🐴 27/10
L 1(40)
C 7(18)
A 5(20)
AM 0(21)
P 1(22)
I 1(19)
R 0(6)
F 0(3)

[21:01] **+32 468 27 83 44:** Carolien - Schoten hele dag 27/10

L 2
C 3
A 0
P 0
I 0
R 0
F 1

---

## 28 oktober 2026

[11:23] **Isaï Melis:** L 0.4
C 0.1
A 1.6
P 1.3
I 1.2
R 0.4
F 0.3

Hoogstraten 28/10

[12:06] **+32 456 96 18 68:** L 0.3
C 0.0
A 0.0
Am 1.3
P 1.4
I 0.2
R 0.0
F 0.0 
Tessenderlo ochtend 28/10

[12:55] **Eva Geerts:** L 3.11
C 2.5
A 0.6
P 1.4
I 0.2
R 0.1
F 0.6

Kapellen 28/10

[13:34] **Pieter Vanstippelen:** L 2.24
C 1.12
A 1.13
Am 0.4
P 1.7
I 0.6
R 0.5
F 0.10
Db 28/10 ochtend

[14:29] **Keith D'Hooge:** L 1.1
C 3.4
A 2.3
P 0.2
I 0.0
R 0.0
F 1.4

Kapellen 27/10 avond

[19:20] **Wout Noppe:** Beveren 28/10
L: 4.50
C: 2.20
A: 0.12
AM: 2.18
P: 0.17
I: 0.13
R: 0.3
F: 0.1

[19:33] **Bieke Stinkens:** L 4.28 (walk in) 
C 0.14
A 1.32
P 4.26
I 3.31
R 0.18
F 0.14
MM 28/10

[19:35] **Charlotte Elen:** L 4.25
C 0.13
A 0.13
P 1.10
I 1.12
R 0.5
F 1.9
Milo 2.8

Brasschaat 28/10

[19:36] **Gilles Lambilot:** [Afbeelding]

[19:47] **Anousjka Christiaens:** Zandhoven 27/10
L 0.24
C 0.23
A 2.31
P 3.19 
I  2.13
IO 0.3
R 0.16
B 0.0
F 0.18
Pelvi lead 0.1
Pelvi afspraak 0.0
Pelvi inschrijving 0.0
BenFit opstart 0.1

[19:52] **Julia van de Goor:** L 1(10)
C 0(3)
A 0(7)
AM 1(8)
P 1(8)
I 1(10)
R 0(4)
F 1(15)

28/10 Tessenderlo

[20:35] **+32 456 96 18 68:** L 3.17
C 1.12
A 0.3
Am 0.3
P 0.7
I 0.6
R 0.4
F 0.2
Db 28/10 avond

[20:50] **Ellen Van de Voorde:** L 0.14
C 0.11
A 0.7
P 0.4
I 1.6
R 0.11
F 0.11

Hoogstraten 28/10

[20:50] **+32 468 27 83 44:** Carolien - Kapellen 28/10 AV

L 3.5
C 0.3
A 2.2
P 2.2
I 2.2
R 1.1
F 2.3

[20:59] **Natasha De Vriendt:** L 0.30
C 0.16
A 0.22
P 1.10 
I 1.6
R 0.8
F 0.10

Schoten 28/10

---

## 29 oktober 2026

[11:27] **Ellen Van de Voorde:** L 1.15
C 0.11
A 1.8
P 2.6
I 1.7
R 0.11
F 0.11

Hoogstraten 29/10

[11:54] **+32 456 96 18 68:** L 2.5
C 1.1
A 0.0
Am 1.4
P 0.4
I 0.2
R 0.0
F 0.0
28/10 Tessenderlo ochtend

[12:53] **+32 468 27 83 44:** Carolien - Kapellen 29/10 VM

L 1.6
C 0.3
A 0.2
P 1.3
I 1.3
R 1.2
F 0.3

[19:30] **Yent'l Adams:** L 4.29
C 0.13
A 0.13
P 1.11
I 1.13
R 0.5
F 0.9
Milo 1.9
Brasschaat 29/10

[19:36] **Bieke Stinkens:** L 4.32 (walk in) 
C 2.16
A 5.37
P 2.28
I 2.33
R 0.18
F 0.14
MM 29/10

[19:55] **Joris Verbeeck:** L 0(17)
C 2(13)
A 1(14)
AM 0(7)
P 2(10)
I 2(12)
R 2(10)
F 2(6)

29/10 Tessenderlo

[19:55] **Beau Massignani:** L 1(29)
C 1(15)
A 1(12)
AM 0(8)
P 0(9)
I 0(9)
R 1(10)
F 1(12)
29/10 HH Lanaken

[20:06] **Gilles Lambilot:** [Afbeelding]

[20:10] **+32 456 96 18 68:** L 0.17
C 0.12
A 0.3
Am 0.3
P 0.7
I 0.6
R 0.4
F 0.2
Db 29/10 avond

[20:35] **Isaï Melis:** L 1.5
C 0.1
A 0.6
P 0.3
I 0.2
R 0.4
F 0.3

Hoogstraten 29/10

[20:35] **Ans Van Hofstraeten:** Zandhoven 29/10
L 1.25
C 1.24
A 0.31
P 4.23
I  2.15
IO 0.3
R 0.16
B 0.0
F 1.19
Pelvi lead 0.1
Pelvi afspraak 0.0
Pelvi inschrijving 0.0
BenFit opstart 0.1

[20:40] **Eva Geerts:** L 4.15
C 3.8
A 3.9
P 1.5
I 0.2
R 1.2
F 0.6

Schoten 29/10

[20:45] **Wilma Mihaylova:** Beveren 29/10
L: 4.54
C: 4.24
A: 2.14
AM: 2.20
P: 1.18
I: 0.13
R: 0.3
F: 0.1

[20:48] **Yentl De Clippeleir:** DMD OV 🐴 28/10
L 1(41)
C 0(18)
A 0(20)
AM 0(21)
P 1(23)
I 1(20)
R 0(6)
F 0(3)

[20:49] **Yentl De Clippeleir:** DMD OV 🐴 29/10
L 1(41)
C 2(20)
A 1(21)
AM 0(21)
P 2(25)
I 1(21)
R 0(6)
F 0(3)

---

## 30 oktober 2026

[11:28] **Isaï Melis:** L 0.5
C 0.1
A 0.6
P 0.3
I 0.2
R 0.4
F 0.3

Hoogstraten 30/10

[11:41] **Anousjka Christiaens:** Zandhoven 30/10
L 1.25
C 0.24
A 1.31
P 0.23
I  0.15
IO 0.3
R 1.16
B 0.0
F 1.19
Pelvi lead 0.1
Pelvi afspraak 0.0
Pelvi inschrijving 0.0
BenFit opstart 0.1

[12:28] **Julia van de Goor:** L 1(11)
C 0(3)
A 1(8)
AM 1(9)
P 1(9)
I 1(11)
R 0(4)
F 0(15)

30/10 Tessenderlo

[12:29] **Eva Geerts:** L 1.16
C 0.8
A 0.9
P 1.6
I 2.4
R 0.2
F 0.6

Schoten 30/10

[12:29] **Wilma Mihaylova:** Beveren30/10
L: 0.54
C: 1.25
A: 0.14
AM: 0.20
P: 1.19
I: 1.14
R: 0.3
F: 0.1

[12:30] **Bruno Rivas:** [Afbeelding]

[12:34] **Beau Massignani:** L 1.33
C 0.16
A 0.37
P 2.30
I 2.35
R 1.19
F 0.14
MM 30/10

[12:37] **+32 456 96 18 68:** L 2.19
C 4.16
A 1.4
Am 0.3
P 1.8
I 1.7
R 0.4
F 0.2
Db 30/10 ochtend

[12:38] **Natasha De Vriendt:** L 1.31
C 1.17
A 0.22
P 0.10 
I 0.6
R 0.8
F 1.11

Kapellen 30/10

[13:03] **+32 468 27 83 44:** Carolien - Kapellen 30/10 VM

L 1.7
C 0.3
A 0.2
P 1.4
I 1.4
R 0.2
F 1.4

[20:14] **Pieter Vanstippelen:** L 0.24
C 1.13
A 1.14
Am 0.5
P 0.7
I 0.6
R 0.5
F 0.10
Db 30/10 ochtend

---

## 31 oktober 2026

[11:23] **Isaï Melis:** L 0.5
C 0.1
A 0.6
P 0.3
I 0.2
R 0.4
F 0.3

Hoogstraten 31/10

[11:35] **Bieke Stinkens:** L 0.33
C 0.16
A 0.37
P 0.30
I 0.35
R 0.19
F 0.14
MM 31/10

[11:49] **Ans Van Hofstraeten:** Zandhoven 31/10
L 0.25
C 0.24
A 0.31
P 1.24
I  1.16
IO 0.3
R 0.16
B 0.0
F 1.20
Pelvi lead 0.1
Pelvi afspraak 0.0
Pelvi inschrijving 0.0
BenFit opstart 0.1

[12:01] **Wout Noppe:** Beveren31/10
L: 3.57
C: 1.26
A: 0.14
AM: 2.22
P: 1.20
I: 1.15
R: 0.3
F: 0.1

[12:06] **Julia van de Goor:** L 0(11)
C 0(3)
A 0(8)
AM 0(9)
P 0(9)
I 0(11)
R 0(4)
F 1(16)

31/10 Tessenderlo

[12:07] **Elias De Bruyne:** DMD OV 🐴 31/10
L 3(44)
C 1(22)
A 1(22)
AM 1(22)
P 0(25)
I 0(21)
R 0(6)
F 0(3)

[12:24] **Natasha De Vriendt:** L 1.32
C 1.18
A 1.23
P 0.10 
I 0.6
R 0.8
F 0.11

Kapellen 31/10

[12:25] **Gilles Lambilot:** [Afbeelding]

[12:32] **+32 456 96 18 68:** L 2.21
C 1.17
A 1.5
Am 0.3
P 0.8
I 0.7
R 0.4
F 0.2
Db 31/10 ochtend

[12:49] **Rob Coppieters:** L 0.6
C 0.4
A 0.7
P 1.3
I 1.4
R 2.4
F 0.4
Schoten 31/10👻

[12:54] **Wilma Mihaylova:** DMD MST🐴27-31 /10
L 6(21)
C 3(8)
A 3(3)
AM 3(15)
P 1(13
I 2(15)
IO 0(0)
R 1(3)
F zie OV

---

## 1 november 2026

[12:38] **Natasha De Vriendt:** L 1.1
C 1.1
A 1.1
P 1.1
I 1.1
R 1.1
F 0.0

Schoten 01/11

[12:47] **Ellen Van de Voorde:** L 3.3
C 0.0
A 3.3
P 0.0
I 0.0
R 1.1
F 0.0

Kapellen 01/11

[13:52] **Anousjka Christiaens:** Zandhoven 1/11
L 0.25
C 0.24
A 0.31
P 0.24
I  0.16
IO 0.3
R 0.16
B 0.0
F .20
Pelvi lead 0.1
Pelvi afspraak 0.0
Pelvi inschrijving 0.0
BenFit opstart 0.1
